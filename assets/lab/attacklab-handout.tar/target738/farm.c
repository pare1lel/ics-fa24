/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_213()
{
    return 3284633944U;
}

unsigned getval_220()
{
    return 2425376814U;
}

unsigned addval_195(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_104(unsigned x)
{
    return x + 1222914184U;
}

unsigned addval_216(unsigned x)
{
    return x + 2999160920U;
}

void setval_123(unsigned *p)
{
    *p = 1505974491U;
}

unsigned getval_219()
{
    return 3347662954U;
}

void setval_353(unsigned *p)
{
    *p = 3348711671U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_239(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_234()
{
    return 3265912972U;
}

unsigned getval_424()
{
    return 3373846921U;
}

unsigned getval_374()
{
    return 3534016137U;
}

void setval_418(unsigned *p)
{
    *p = 3523792521U;
}

void setval_144(unsigned *p)
{
    *p = 3536113289U;
}

unsigned getval_464()
{
    return 2425672073U;
}

unsigned getval_122()
{
    return 3281113481U;
}

void setval_279(unsigned *p)
{
    *p = 3221799565U;
}

unsigned getval_491()
{
    return 3285059898U;
}

void setval_255(unsigned *p)
{
    *p = 3224949129U;
}

void setval_222(unsigned *p)
{
    *p = 3224424073U;
}

void setval_217(unsigned *p)
{
    *p = 3526939017U;
}

void setval_387(unsigned *p)
{
    *p = 2425409945U;
}

void setval_317(unsigned *p)
{
    *p = 2425406089U;
}

unsigned getval_408()
{
    return 2430601544U;
}

unsigned addval_278(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_162()
{
    return 3771287712U;
}

unsigned getval_114()
{
    return 767807753U;
}

void setval_152(unsigned *p)
{
    *p = 3526938313U;
}

unsigned getval_271()
{
    return 3285092852U;
}

unsigned addval_192(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_302()
{
    return 3224949131U;
}

unsigned addval_379(unsigned x)
{
    return x + 3229926025U;
}

unsigned getval_127()
{
    return 3286272328U;
}

unsigned getval_414()
{
    return 3281306249U;
}

unsigned addval_365(unsigned x)
{
    return x + 3766569097U;
}

unsigned addval_296(unsigned x)
{
    return x + 3285100891U;
}

void setval_451(unsigned *p)
{
    *p = 3523265161U;
}

unsigned getval_497()
{
    return 3286272329U;
}

unsigned getval_124()
{
    return 3229926027U;
}

unsigned getval_417()
{
    return 3284273471U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
